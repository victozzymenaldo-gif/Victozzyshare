package com.victozzy.share

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.p2p.*
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var status: TextView
    private lateinit var peersText: TextView
    private lateinit var logText: TextView
    private lateinit var discoverButton: Button
    private lateinit var sendButton: Button
    private var peers: List<WifiP2pDevice> = emptyList()
    private var groupOwnerAddress: String? = null
    private val io = Executors.newSingleThreadExecutor()
    private var serverStarted = false

    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) sendSelectedFile(uri)
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        discoverPeers()
    }

    private val peerListener = WifiP2pManager.PeerListListener { list ->
        peers = list.deviceList.toList()
        runOnUiThread {
            peersText.text = if (peers.isEmpty()) "No devices found yet. Make sure the other phone has VICTOZZY SHARE open and is discovering." else
                peers.mapIndexed { i, d -> "${i + 1}. ${d.deviceName}  (${stateName(d.status)})" }.joinToString("\n")
            discoverButton.isEnabled = true
        }
    }

    private val connectionListener = WifiP2pManager.ConnectionInfoListener { info ->
        if (info.groupFormed) {
            groupOwnerAddress = info.groupOwnerAddress?.hostAddress
            val owner = info.isGroupOwner
            runOnUiThread {
                status.text = if (owner) "Connected — this phone is ready to receive" else "Connected — ready to send"
                sendButton.isEnabled = !owner
            }
            if (owner) startReceiveServer()
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                    if (hasPermissions()) manager.requestPeers(channel, peerListener)
                }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> manager.requestConnectionInfo(channel, connectionListener)
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val enabled = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                    runOnUiThread { if (!enabled) status.text = "Turn on Wi-Fi to use offline sharing" }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper, null)
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, filter)
        requestNeededPermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF090611.toInt())
        }
        val brand = TextView(this).apply {
            text = "VICTOZZY SHARE"
            textSize = 26f
            setTextColor(0xFFC084FC.toInt())
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val tagline = TextView(this).apply {
            text = "SHARE ANYTHING. ANYWHERE."
            textSize = 11f
            letterSpacing = .18f
            gravity = Gravity.CENTER
            setTextColor(0xFFB9A9CE.toInt())
        }
        status = TextView(this).apply {
            text = "Offline sharing • Wi-Fi Direct"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 28, 8, 20)
        }
        discoverButton = makeButton("FIND NEARBY PHONES") { requestNeededPermissions(); discoverPeers() }
        sendButton = makeButton("CHOOSE FILE TO SEND") { pickFile.launch("*/*") }
        sendButton.isEnabled = false
        val receive = TextView(this).apply {
            text = "HOW TO CONNECT\n1. Open VICTOZZY SHARE on both phones.\n2. Tap FIND NEARBY PHONES on both.\n3. Select a device from the list below.\n4. Accept the connection request on the other phone.\n5. The connected phone can choose a file to send."
            textSize = 14f
            setTextColor(0xFFE9DDF7.toInt())
            setPadding(4, 18, 4, 18)
        }
        peersText = TextView(this).apply {
            text = "Nearby devices will appear here."
            textSize = 14f
            setTextColor(0xFFD8C8EA.toInt())
            setPadding(4, 8, 4, 12)
        }
        logText = TextView(this).apply { textSize = 12f; setTextColor(0xFFC084FC.toInt()) }
        root.addView(brand); root.addView(tagline); root.addView(status)
        root.addView(discoverButton); root.addView(sendButton); root.addView(receive)
        root.addView(peersText); root.addView(logText)
        setContentView(ScrollView(this).apply { addView(root) })
        peersText.setOnClickListener { showPeerPicker() }
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF7E22CE.toInt()))
        setPadding(12, 14, 12, 14)
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 8, 0, 8)
        layoutParams = p
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            needed += Manifest.permission.NEARBY_WIFI_DEVICES
            needed += Manifest.permission.READ_MEDIA_IMAGES
            needed += Manifest.permission.READ_MEDIA_VIDEO
            needed += Manifest.permission.READ_MEDIA_AUDIO
        } else {
            needed += Manifest.permission.ACCESS_FINE_LOCATION
        }
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    private fun hasPermissions(): Boolean = if (Build.VERSION.SDK_INT >= 33)
        checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED
    else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun discoverPeers() {
        if (!hasPermissions()) { requestNeededPermissions(); return }
        discoverButton.isEnabled = false
        status.text = "Searching for nearby phones…"
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { runOnUiThread { status.text = "Searching… tap a device name when it appears" } }
            override fun onFailure(reason: Int) { runOnUiThread { status.text = "Discovery failed: ${reasonText(reason)}"; discoverButton.isEnabled = true } }
        })
        manager.requestPeers(channel, peerListener)
    }

    private fun showPeerPicker() {
        if (peers.isEmpty()) { toast("Find nearby phones first"); return }
        val names = peers.map { it.deviceName }.toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Connect to a phone").setItems(names) { _, which ->
            val device = peers[which]
            if (!hasPermissions()) { requestNeededPermissions(); return@setItems }
            status.text = "Connecting to ${device.deviceName}…"
            val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
            manager.connect(channel, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { toast("Connection request sent") }
                override fun onFailure(reason: Int) { status.text = "Connection failed: ${reasonText(reason)}" }
            })
        }.show()
    }

    private fun startReceiveServer() {
        if (serverStarted) return
        serverStarted = true
        Thread {
            try {
                ServerSocket(8988).use { server ->
                    while (!isFinishing) {
                        val socket = server.accept()
                        io.execute { receiveFile(socket) }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { logText.text = "Receiver stopped: ${e.message}" }
                serverStarted = false
            }
        }.start()
    }

    private fun receiveFile(socket: Socket) {
        socket.use { s ->
            DataInputStream(BufferedInputStream(s.getInputStream())).use { input ->
                val name = input.readUTF().replace(Regex("[^A-Za-z0-9._ -]"), "_")
                val size = input.readLong()
                if (size < 0 || size > 2_000_000_000L) throw IOException("Invalid file size")
                val dir = getExternalFilesDir("received") ?: filesDir
                val outFile = File(dir, name)
                FileOutputStream(outFile).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var remaining = size
                    while (remaining > 0) {
                        val count = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                        if (count < 0) throw EOFException("Transfer interrupted")
                        out.write(buffer, 0, count)
                        remaining -= count
                    }
                }
                runOnUiThread { logText.text = "Received: $name (${size / 1024} KB). Saved inside app storage." }
            }
        }
    }

    private fun sendSelectedFile(uri: Uri) {
        val host = groupOwnerAddress
        if (host == null) { toast("Connect to a phone first"); return }
        io.execute {
            try {
                val name = queryName(uri)
                val size = contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
                if (size < 0) throw IOException("Cannot read file size")
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, 8988), 15000)
                    DataOutputStream(BufferedOutputStream(socket.getOutputStream())).use { out ->
                        out.writeUTF(name); out.writeLong(size)
                        contentResolver.openInputStream(uri).use { input ->
                            if (input == null) throw IOException("Cannot open selected file")
                            input.copyTo(out, 64 * 1024)
                        }
                        out.flush()
                    }
                }
                runOnUiThread { logText.text = "Sent successfully: $name" }
            } catch (e: Exception) { runOnUiThread { logText.text = "Send failed: ${e.message}" } }
        }
    }

    private fun queryName(uri: Uri): String {
        var result = "shared_file"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) result = c.getString(i) ?: result
            }
        }
        return result
    }

    private fun stateName(state: Int) = when (state) {
        WifiP2pDevice.AVAILABLE -> "available"
        WifiP2pDevice.CONNECTED -> "connected"
        WifiP2pDevice.INVITED -> "invited"
        else -> "unavailable"
    }
    private fun reasonText(reason: Int) = when (reason) {
        WifiP2pManager.P2P_UNSUPPORTED -> "Wi-Fi Direct not supported"
        WifiP2pManager.BUSY -> "Wi-Fi is busy"
        WifiP2pManager.ERROR -> "system error"
        else -> "reason $reason"
    }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        io.shutdownNow()
        super.onDestroy()
    }
}
