# VICTOZZY SHARE — Android starter project

A native Kotlin Android starter for offline Wi-Fi Direct file sharing, with a dark black/purple interface.

## Open and build
1. Install Android Studio (latest stable) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator (Wi-Fi Direct needs real devices).
5. Press Run.

## Current implementation
- Android Wi-Fi Direct peer discovery and connection requests.
- Simple TCP file transfer over the Wi-Fi Direct group-owner connection.
- Android system file picker for selecting a file.
- Received files are saved in the app's private `Android/data/com.victozzy.share/files/received` folder.

## Important limitations / next steps
- This is an initial development build, not a tested production APK.
- Both phones must have Wi-Fi enabled and support Wi-Fi Direct; vendor Android implementations differ.
- Connection approval and discovery behavior should be tested on multiple physical devices.
- The UI currently shows discovered devices in a list; tap the list to choose one.
- Add transfer progress, cancellation, duplicate-name handling, QR pairing, stronger protocol validation, and foreground-service support before public release.
- For Android 12 and below, location permission is needed by Android for Wi-Fi Direct discovery. On Android 13+, Nearby Wi-Fi Devices permission is requested.
- No ads or payments are included yet. Add AdMob only after core transfers are reliable and a privacy policy is published.

Package: `com.victozzy.share`

## Build APK from your phone with GitHub Actions
1. Create/sign in to a GitHub account in Chrome.
2. Create a new public or private repository named `victozzy-share`.
3. Upload the contents of this project ZIP into the repository (not the ZIP itself), preserving folders including `.github`.
4. Open the repository's Actions tab and enable workflows if prompted.
5. Choose **Build VICTOZZY SHARE APK** and tap **Run workflow** (or wait for the first push build).
6. When the run succeeds, open it and download the `VICTOZZY-SHARE-debug-APK` artifact. Extract the ZIP to get `app-debug.apk`.
